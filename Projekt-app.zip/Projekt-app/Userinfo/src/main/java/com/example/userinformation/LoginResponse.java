package com.example.userinformation;

public class LoginResponse {
    String response;

    public void setResponse(String response) {
        this.response = response;
    }

    public LoginResponse(String response) {
        this.response = response;
    }

    public String getResponse() {
        return response;
    }
}
